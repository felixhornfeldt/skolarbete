Project Hype
Ni ska skapa en webbsida som ska Hypa något av nedanstående koncept.
Sidan ska innehålla en huvudsida och minst tre undersidor.
På varje sida ska det finnas en lättnavigerat meny som gör att du kan gå mellan sidorna.
Texter (utöver rubriker) behöver ni inte hitta på själv. Använd en "Lorem Ipsum"-generator(se bifogad länk eller använd editorn) för att skapa nonsenstexter.

Bilder på sidorna skall vara
En header, bearbetad i Photoshop
Övriga bilder, bearbetade i Photoshop
Annat innehåll, kopplat till sitens tema

Innan ni börjar implementera sidan med HTML och CSS ska ni ha gjort skisser med papper och penna på varje sidas layout. Dessa skisser ska ni fota och placera i misc-mappen.

Ni kommer slumpas in i något av följande teman. 
Gör följande beräkning för att ta reda på vilket tema din grupp ska hypa: (Din grupps nummer) % 5
Exempel, Grupp 13: 13 % 5 => 3. Rick Astley

0. Equifax™
1. Tesla Solar Roof™
2. Microsoft Edge™
3. Rick Astley (Rickroll är strikt förbjudet)
4. Gummiankor (http://rubber-duck-debugging.org/)

Tänk på!
Skissa först
Mappstruktur och sökvägar
Använd semantiska behållarelement (t.ex. header, nav, main, footer)
Indentera din kod (knuffa till höger med tab-knappen.. knuffa till vänster med shift+tab)